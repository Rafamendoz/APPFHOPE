<?php $__env->startSection('tablabase'); ?>
 <!-- Page Heading -->
 <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
  <ol class="bg-white breadcrumb shadow p-3 mb-4 rounded">
    <li class="breadcrumb-item active" aria-current="page">Usuarios</li>
  </ol>
</nav>


                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Data de Usuarios</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-plus fa-sm fa-fw text-primary-400"></i>
                                        </a>

                                       

                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Acciones</div>
                                            <a class="dropdown-item" href="<?php echo e(route('AddUsuario', ['destination' => 'AddUsuario', 'value' => 'r'])); ?>">Agregar Usuarios</a>
                                            <div class="dropdown-divider"></div>
                                        </div>
                                    </div>
                                </div>

                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered " id="dataTable" width="100%" cellspacing="0">
                                    <thead class="text-center">
                                        <tr>
                                            <th>Identificador</th>
                                            <th>Email</th>
                                            <th>Usuario</th>
                                            <th>Intentos</th>
                                            <th>Estado</th>
                                            <th>Creacion</th>
                                            <th>Actualizacion</th>
                                            <th>Acciones</th>

                                        </tr>
                                    </thead>
                            
                                 <tbody class="text-center">
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($valor->id); ?></td>
                                                <td><?php echo e($valor->email); ?></td>
                                                <td><?php echo e($valor->user); ?></td>
                                                <td><?php echo e($valor->intentos); ?></td>
                                                <?php if($valor->valor=="ACTIVO"): ?>
                                                <td><div class="rounded-pill bg-success text-white"><b><?php echo e($valor->valor); ?></b></div></td>
                                                <td><?php echo e($valor->created_at); ?></td>
                                                <td><?php echo e($valor->updated_at); ?></td>
                                                <td>
                                                            <button class="btn btn-danger btn-sm" type="button" onclick="ConsultarEliminar(<?php echo e($valor->id); ?>)"><i class="fas fa-trash"></i></button>
                                                            <button class="btn btn-primary btn-sm" type="button"><i class="fas fa-pen"></i></button>              
                                                </td>
                                                <?php endif; ?>    
                                                <?php if($valor->valor=="INACTIVO"): ?>
                                                <td><div class="rounded-pill bg-danger text-white"><b><?php echo e($valor->valor); ?></b></div></td>
                                                <td><?php echo e($valor->created_at); ?></td>
                                                <td><?php echo e($valor->updated_at); ?></td>
                                                <td>
                                                            <button class="btn btn-primary btn-sm" type="button" onclick="ConsultarActivar(<?php echo e($valor->id); ?>)"><i class="fas fa-eye"></i></button>
                                                </td>
                                                <?php endif; ?>                                                
                                          
                                               
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('build/vendor/jquery/jquery.min.js')); ?>"></script>
<script>

    var csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    var authorization ="";
    (function(){
        $.ajax({
        method: "GET",
        url: '../../apiCredenciales',
        headers: {
        'X-CSRF-TOKEN': csrfToken,

         }
        })
        .done(function( data ) {
            let response = JSON.parse(JSON.stringify(data));
            authorization = response.Token;
        
        }).fail(function(data){
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            

        });

    })();

    function ConsultarEliminar(id){
        Swal.fire({
                    title: '¿Está seguro?',
                    text: "No podrás revertir esto!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '¡Sí, bórralo!',
                    cancelButtonText: 'Cancelar'
                    }).then((result) => {
                    if (result.isConfirmed) {
                        Eliminar(id);
                    }
        })
    }

    function ConsultarActivar(id){
        Swal.fire({
                    title: '¿Está seguro?',
                    text: "Se activara el registro!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '¡Sí, activalo!',
                    cancelButtonText: 'Cancelar'
                    }).then((result) => {
                    if (result.isConfirmed) {
                        Activar(id);
                    }
        })
    }

    function Activar(id){

        $.ajax({
        method: "PUT",
        url: "../../api/usuarioR/delete/"+id,
        headers: {
                'X-CSRF-TOKEN': csrfToken,
                'Authorization': 'Basic '+ authorization
        },
        data: { "estado":1}
        })
        .done(function( data ) {
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            mostrarMensaje(response['Data_Respuesta'])

        }).fail(function(data){
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            mostrarMensaje(response['responseJSON']);

        });

    }


    

    function Eliminar(id){

        $.ajax({
        method: "PUT",
        url: "../../api/usuarioR/delete/"+id,
        headers: {
                'X-CSRF-TOKEN': csrfToken,
                'Authorization': 'Basic '+ authorization
        },
        data: { "estado":2}
        })
        .done(function( data ) {
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            mostrarMensaje(response['Data_Respuesta'])
        
        }).fail(function(data){
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            mostrarMensaje(response['responseJSON']);

        });
            
    }

   


    function mostrarMensaje(dataResponse){
         
         const Toast = Swal.mixin({
         toast: true,
         position: 'top-end',
         showConfirmButton: false,
         timer: 3000,
         timerProgressBar: true,
         didOpen: (toast) => {
             toast.addEventListener('mouseenter', Swal.stopTimer)
             toast.addEventListener('mouseleave', Swal.resumeTimer)
         },
         didClose: (toast) => {
                 if(dataResponse.Codigo==200){
                    location.reload();
                 }
     
         }
         })
 
         if(dataResponse.Codigo==200){
                     Toast.fire({
                     icon: 'success',
                     title: dataResponse.Estado + "! " + dataResponse.Descripcion 
                     })
         }else{
                 Toast.fire({
                 icon: 'error',
                 title: dataResponse.Estado + "! " + dataResponse.Mapping_Error[0].descripcion 
                 })
         }
              
    }

    


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panelp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APPFHOPE\resources\views/usuarios.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TipoCompraController extends Controller
{
    //
}

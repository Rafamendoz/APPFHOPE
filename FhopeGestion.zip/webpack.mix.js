const mix = require('laravel-mix');


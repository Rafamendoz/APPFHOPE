<?php $__env->startSection('tablabase'); ?>
 <!-- Page Heading -->

 <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
  <ol class="breadcrumb bg-white shadow p-3 mb-4 rounded">
    <li class="breadcrumb-item active" aria-current="page">POS</li>
  </ol>
</nav>


                    <!-- DataTales Example -->
                  
                        <div class="row">
                            <div class=" col-md-8">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                                            <h5 class=" font-weight-bold text-primary">Datos del Cliente</h5>
                                        </div>
                                    </div>

                                    <div class="card-body">
                                    
                                        <div class="row p-2">
                                            <form class="row g-3">
                                                <div class="col-md-6 mb-3">
                                                    <label for="orden" class="form-label">N.Orden:</label>
                                                    <input class="form-control" id="orden"  readonly  value="<?php echo e($numero_orden); ?>"></input>
                                                </div>
                                                

                                                <div class="col-md-6 mb-3" id="capaTotal" >
                                                    <label for="total" class="form-label">Total:</label>
                                                    <input class="form-control" id="total" value=""   readonly></input>
                                                </div>
                                                <div class="col-md-12 mb-1" id="capaTotal" >
                                                <label for="orden" class="form-label">Tipo de Identificacion:</label>
                                                </div>

                                                <div class="col-md-12 mb-2">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" checked onclick="MostrarIdentificacion()">
                                                        <label class="form-check-label" for="flexRadioDefault1">
                                                            DNI
                                                        </label>
                                                        </div>
                                                        <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2"  onclick="MostrarIdentificacion()">
                                                        <label class="form-check-label" for="flexRadioDefault2">
                                                            Codigo Cliente
                                                        </label>
                                                    </div>
                                                </div>

                                            
                                            
                                                <div class="col-md-6 mb-3">
                                                    <label for="inputEmail4" class="form-label" id="id_label">DNI:</label>
                                                    <input type="number" class="form-control" id="dni">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="inputPassword4" class="form-label">Usuario:</label>
                                                    <input readonly type="text" class="form-control" id="usuario" value="<?php echo e(auth()->user()->user); ?>">
                                                </div>
                                                <div class="col-12 mb-3">
                                                    <label for="inputAddress" class="form-label">Direccion de Envio:</label>
                                                    <input type="text" class="form-control" id="direccion" placeholder="Escriba la direccion...">
                                                </div>
                                            
                                                <div class="col-md-6">
                                                    <label for="inputCity" class="form-label">Nombre del Cliente:</label>
                                                    <input type="text" class="form-control" id="nombrecliente" readonly>
                                                </div>
                                                
                                                <div class="col-md-6 mb-3">
                                                    <label for="inputZip" class="form-label">Correo Electronico:</label>
                                                    <input type="text" class="form-control" id="correo" readonly>
                                                </div>
                                            
                                            
                                            </form>
                                            <div class="col-md-12 ">
                                                    <button onclick="Buscar()" class="btn btn-primary">Buscar</button>
                                            </div>

                                        </div>
                                     
                                    
                                    </div>
                                </div>
                            </div>

                            <div class=" col-md-4">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3 bg-primary">
                                        <div class="d-grid gap-2 d-md-flex justify-content-md-center bg-primary">
                                        </div>
                                    </div>

                                    <div class="card-body bg-white">
                                        
                                            <div class="row p-2">
                                                
                                                    <div class="col-sm-12">
                                                    <h4 class="text-center font-weight-bold text-primary">Productos</h4>
                                                    </div>
                                                
                                                
                                            </div>

                                            <div class="row p-2">
                                                    <form class="row g-3">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="inputEmail4" class="form-label">Codigo Producto:</label>
                                                            <input type="number" class="form-control" id="producto_codigo">
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="inputCity" class="form-label">Cantidad:</label>
                                                            <input type="number" class="form-control" id="cantidad" readonly>
                                                        </div>
                                                        <div class="col-md-12 mb-3">
                                                            <label for="inputPassword4" class="form-label">Nombre:</label>
                                                            <input readonly type="text" class="form-control" id="nombre">
                                                        </div>
                                                        <div class="col-12 mb-3">
                                                            <label for="inputAddress" class="form-label">Descripcion:</label>
                                                            <input readonly type="text" class="form-control" id="descripcion">
                                                        </div>

                                                        <div class="col-12 mb-3" hidden  id="CapaDetalleProducto">
                                                     
                                                            <div class="input-group mb-3">
                                                                <div class="input-group-prepend">
                                                                    <label class="input-group-text" for="color">Colores</label>
                                                                </div>
                                                                <select class="custom-select" id="color">
                                                                    <option selected value="0">Seleccione...</option>
                                                                    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($valor->id); ?>"><?php echo e($valor->name_color); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                
                                                                </select>

                                                                <div class="input-group-prepend">
                                                                    <label class="input-group-text" for="size">Tallas</label>
                                                                </div>
                                                                <select class="custom-select" id="size">
                                                                    <option selected value="0">Seleccione...</option>
                                                                
                                                                </select>
                                                            </div>

                                            
                                                        </div>


                                                        <div class="col-12 mb-3" hidden id="CapaDescuento">
                                                            <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" id="gridCheck" onclick="MostrarDescuento()">
                                                            <label class="form-check-label" for="gridCheck">
                                                                Aplicar Descuento?
                                                            </label>
                                                            </div>
                                                        </div>
                                                    
                                                        
                                                
                                                        <div class="col-md-12 mb-3" hidden id="CapaCantidadDescuento">
                                                            <label for="inputCity" class="form-label">Descuento en Lempiras:</label>
                                                            <input type="number" class="form-control" id="descuento" >
                                                        </div>


                                                
                                                
                                                
                                                    </form>

                                                    <div class="col-12" id="CapaBotonBuscarProducto">
                                                        <button onclick="BuscarProducto()" class="btn btn-primary">Buscar</button>
                                                    </div>

                                                    <div class="col-12" id="CapaBotonAgregar" hidden>
                                                        <button onclick="ValidarDatos()" class="btn btn-warning">Agregar</button>
                                                        <button onclick="ResetFormProductos()" class="btn btn-danger">Cancelar</button>

                                                    </div>
                                    
                                            </div>


                

                                    </div>
                                
                                    
                                    
                                </div>

                            </div>


                        </div>

                        <div class="row">
                            <div class=" col-md-12">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                                            <h5 class=" font-weight-bold text-primary">Detalle de Pedido</h5>
                                        </div>
                                    </div>

                                    <div class="card-body">
                                    <div class="table-responsive">
                                <table class="table table-bordered " id="table2" width="100%" cellspacing="0">
                                    <thead class="text-center">
                                        <tr>
                                            <th>Codigo Producto</th>
                                            <th>Nombre</th>
                                            <th>Precio</th>
                                            <th>Talla</th>
                                            <th>Color</th>
                                            <th>Cantidad</th>
                                            <th>Descuento</th>
                                            <th>Isv</th>
                                            <th>Subtotal</th>
                                            <th hidden>valorTalla</th>
                                            <th hidden>valorColor</th>
                                            <th>Acciones</th>



                                        </tr>
                                    </thead>
                            
                                        <tbody class="text-center" id="tbody">
                                          
                                            
                                            
                                        </tbody>
                                        <tfoot>
                                            <div class="col-12 mb-2" id="CapaEnviarOrden" hidden>
                                                            <button onclick="ConfirmarPagar()" class="btn btn-warning">Generar Orden</button>
                                            </div>
                                        </tfoot>
                                     
                                </table>
                            </div>
                                        
                                       

                                    </div>
                                </div>
                            </div>



                        </div>

                    
                  

                    
             


        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('build/vendor/jquery/jquery.min.js')); ?>"></script>

<script>
    var disparadorMensaje = 0;
    $('#color').change(function(){ 
            var value = $(this).val();
            let codigoproducto = $("#producto_codigo").val();
            ObtenerTallas(value,codigoproducto);
    });
    var csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    var authorization ="";
    (function(){
        $.ajax({
        method: "GET",
        url: '../../apiCredenciales',
        headers: {
        'X-CSRF-TOKEN': csrfToken,

         }
        })
        .done(function( data ) {
            let response = JSON.parse(JSON.stringify(data));
            authorization = response.Token;
        
        }).fail(function(data){
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            

        });

    })();
    


    let productoactual;
    let contadorf=0;
    let idcliente=0;
 
            $( document ).ready(function() {
        $( "#table2" ).bind( "click", function( event ) {
            if(event.target.matches(".eliminarRow")){
                const index =event.target.parentNode.parentNode.rowIndex;
                let tabla = document.getElementById("table2");
                tabla.deleteRow(index);
                total();
            }
         
        });
        });
   
  

    
   

    function Buscar(){

        let dni = $("#dni").val();
        if(dni==""){
             
            const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            },
     
            })

            Toast.fire({
                    icon: 'warning',
                    title: 'No ha completado los datos requeridos' 
                    })


        }else{
            let urldinamica="";
            if($('#flexRadioDefault1').is(':checked')){
                urldinamica ="../../api/clienteR/dni/"+dni;
            }else{
                urldinamica ="../../api/clienteR/active/"+dni;
            }
            
        $.ajax({
        method: "GET",
        url: urldinamica,
        headers: {
        'X-CSRF-TOKEN': csrfToken,
        'Authorization': 'Basic '+ authorization

         }
        })
        .done(function( data ) {

            let response = JSON.parse(JSON.stringify(data));
            if(response.Data_Respuesta.Codigo ==200){
                $("#correo").val(response['Cliente'][0].cliente_correo);
                $("#nombrecliente").val(response['Cliente'][0].cliente_nom);
                idcliente = response['Cliente'][0].id;
                mostrarMensaje(response['Data_Respuesta']);

            }else{
                mostrarMensaje(response['Data_Respuesta']);


            }
          

        
        }).fail(function(data){
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            mostrarMensaje(response['responseJSON']);

        });

        }


      
    }
    
    function BuscarProducto(){

        let codigoproducto = $("#producto_codigo").val();
       
        if(codigoproducto==""){
            
            const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            },

            })

            Toast.fire({
                    icon: 'warning',
                    title: 'No ha completado los datos requeridos' 
                    })


        }else{
            
            $.ajax({
            method: "GET",
            headers: {
                'X-CSRF-TOKEN': csrfToken,
                'Authorization':'Basic '+authorization
            

            },
            url: "../../api/productoR/"+codigoproducto,
            })
            .done(function( data ) {
                let response = JSON.parse(JSON.stringify(data));
                if(response['Data_Respuesta'].Codigo==200){
                    productoactual = response;
                    $("#nombre").val(response['Producto'].producto_nom);
                    $("#descripcion").val(response['Producto'].producto_des);
                    mostrarMensaje(response['Data_Respuesta']);
                    $("#CapaBotonBuscarProducto").attr('hidden',true);
                    $("#CapaBotonAgregar").attr('hidden',false);
                    $("#CapaDescuento").attr('hidden',false);
                    $("#cantidad").attr('readonly',false);
                    $("#CapaDetalleProducto").attr('hidden',false);


                }else{
                    mostrarMensaje(response['Data_Respuesta']);
                }
                
            }).fail(function(data){
                let response = JSON.parse(JSON.stringify(data));
                console.log(response);
                mostrarMensaje(response['responseJSON']);

            });

        }



    }

   

    function MostrarDescuento(){
        if($("#gridCheck").is(":checked")){
            $("#CapaCantidadDescuento").attr('hidden',false);
        }else{
            $("#CapaCantidadDescuento").attr('hidden',true);
        }
    }

    function MostrarIdentificacion(){
        if($('#flexRadioDefault1').is(':checked')){
            $('#id_label').html("DNI:")
        }else{
            $('#id_label').html("Codigo Cliente:")
        }
    }

    function ValidarDatos(){
        let codigoproducto = $("#producto_codigo").val();
        let cantidad = $("#cantidad").val();
        let talla = $("#size").val();
        let color = $("#color").val();
        let mensaje = "";
        if(codigoproducto=="" || cantidad =="" || talla=="" || color=="" || cantidad <=0 || talla <=0 || color <=0){
            mensaje = {"Codigo":"202","Estado":"Aceptado", "Descripcion":"Los campos ingresados no son permitidos, favor revisar"};
            mostrarMensaje(mensaje);
        }else{
            ValidarInventario();
        }

    }

    function ValidarInventario(){
        let codigoproducto = $("#producto_codigo").val();
        let cantidad = $("#cantidad").val();
        let talla = $("#size").val();
        let color = $("#color").val();
        let inventarioDisponible = 0;

        $.ajax({
            method: "GET",
            headers: {
                'X-CSRF-TOKEN': csrfToken,
                'Authorization':'Basic '+authorization
            

            },
            url: "../../api/inventoryR/stockDisponible/"+codigoproducto+"/"+color+"/"+talla
            })
            .done(function( data ) {
                let response = JSON.parse(JSON.stringify(data));
                switch (response['Data_Respuesta'].Codigo) {
                    case '200':
                   
                        inventarioDisponible = response['InventoryDisponible'][0].Stock_Disponible;
                        if(parseInt(cantidad)>parseInt(inventarioDisponible)){
                            let mensaje = {"Codigo":"202","Estado":"Aceptado", "Descripcion":"La cantidad ingresada supera el inventario disponible"};
                            mostrarMensaje(mensaje);
                        }else{
                            AdicionarProducto();

                        }
                        break;

                    case '202':
                        mostrarMensaje(response['Data_Respuesta']);
                        break;

                
                    default:
                        break;
                }
                    
            }).fail(function(data){
                let response = JSON.parse(JSON.stringify(data));
                console.log(response);
                mostrarMensaje(response['responseJSON']);

            });

    }

    function AdicionarProducto(){
        let precio = productoactual["Producto"].precio;
        let cantidad = $("#cantidad").val();
        let descuentounitario = $("#descuento").val();
        let descuentot = descuentounitario*cantidad;
        let isv = 0.00;
        let talla =document.getElementById("size");
        let selectedTalla = talla.options[talla.selectedIndex].text;
        let color =document.getElementById("color");
        let selectedColor = color.options[color.selectedIndex].text;
        let subtotal = (precio*cantidad)-descuentot;
        if(contadorf ==0){
            $("#tbody tr").remove();
            contadorf+=1;
            $("#tbody").append("<tr><td>"+productoactual["Producto"].id+"</td>"+
            "<td>"+productoactual["Producto"].producto_nom+"</td>"+
            "<td>"+precio+"</td>"+
            "<td>"+selectedTalla+"</td>"+
            "<td>"+selectedColor+"</td>"+
            "<td>"+cantidad+"</td>"+
            "<td>"+descuentot+"</td>"+
            "<td>"+isv+"</td>"+
            "<td>"+subtotal+"</td>"+
            "<td hidden>"+talla.value+"</td>"+
            "<td hidden>"+color.value+"</td>"+
            "<td><button class=\"btn btn-danger btn-sm eliminarRow\" type=\"button\"><i class=\"fas fa-trash\"></i></button></td>"+
            "</tr>");
            $("#capaTotal").attr("hidden", false);

            $("#CapaEnviarOrden").attr("hidden", false);
            ResetFormProductos();
        }else{
            $("#tbody").append("<tr><td>"+productoactual["Producto"].id+"</td>"+
            "<td>"+productoactual["Producto"].producto_nom+"</td>"+
            "<td>"+precio+"</td>"+
            "<td>"+selectedTalla+"</td>"+
            "<td>"+selectedColor+"</td>"+
            "<td>"+cantidad+"</td>"+
            "<td>"+descuentot+"</td>"+
            "<td>"+isv+"</td>"+
            "<td>"+subtotal+"</td>"+
            "<td hidden>"+talla.value+"</td>"+
            "<td hidden >"+color.value+"</td>"+
            "<td><button class=\"btn btn-danger btn-sm eliminarRow\" type=\"button\"><i class=\"fas fa-trash\"></i></button></td>"+
            "</tr>");
            contadorf+=1;
            ResetFormProductos();

        }
        total();
    }

    function mostrarMensaje(dataResponse){
         
        const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        },
        
        })

        switch(dataResponse.Codigo){
            case "200":
                Toast.fire({
                    icon: 'success',
                    title: dataResponse.Estado + "! " + dataResponse.Descripcion 
                });
                break;

            case "202":
                Toast.fire({
                    icon: 'info',
                    title: dataResponse.Descripcion 
                });
                break;

            default:
                Toast.fire({
                icon: 'error',
                title: dataResponse.Estado + "! " + dataResponse.Mapping_Error[0].descripcion 
                });
                break;



        }

      
             
    }

    function mostrarMensajeRecibo(dataResponse){
         
         const Toast = Swal.mixin({
         toast: true,
         position: 'top-end',
         showConfirmButton: false,
         timer: 3000,
         timerProgressBar: true,
         didOpen: (toast) => {
             toast.addEventListener('mouseenter', Swal.stopTimer)
             toast.addEventListener('mouseleave', Swal.resumeTimer)
         },
         didClose: (toast) => {
                 if(dataResponse.Codigo==200){
                    $("#CapaEnviarOrden").attr("hidden", true);
                    $("#CapaBotonBuscarProducto").attr("hidden", true);
                    $("#CapaBotonBuscarVz").attr("hidden", true);

                    
                    ConsultarVerRecibo();
                 }else{
                     console.log("NULL");
 
                 }
     
         }
         })
 
         if(dataResponse.Codigo==200){
                     Toast.fire({
                     icon: 'success',
                     title: dataResponse.Estado + "! " + dataResponse.Descripcion 
                     })
         }else{
                 Toast.fire({
                 icon: 'error',
                 title: dataResponse.Estado + "! " + dataResponse.Mapping_Error[0].descripcion 
                 })
           }
              
     }
 

    function ResetFormProductos(){
        $("#CapaDetalleProducto").attr('hidden',true);
        $('#color').val(0);
        $("#size").find('option').not(':first').remove();


        $("#CapaBotonBuscarProducto").attr('hidden',false);
        $("#gridCheck").prop("checked",false);
        $("#CapaCantidadDescuento").attr('hidden',true);
        $("#CapaBotonAgregar").attr('hidden',true);
        $("#cantidad").attr('readonly',true);
        $("#nombre").val('');
        $("#descripcion").val('');
        $("#cantidad").val('');
        $("#CapaDescuento").attr('hidden',true);
        $("#descuento").val("0.00");

        
       
    
        

        
    }
    
    function recorrer(){
            let count =0;
            let conteoexito = 0;
            let pos = $('#table2 tr').length-1
            $('#table2 tr').each(function () {

                        if(count>0){
                            var codigo = $(this).find("td").eq(0).html();
                            var precio = $(this).find("td").eq(2).html();
                            var cantidad = $(this).find("td").eq(5).html();
                            var descuento = $(this).find("td").eq(6).html();
                            var isv = $(this).find("td").eq(7).html();
                            var subtotal = $(this).find("td").eq(8).html();
                            var talla = $(this).find("td").eq(9).html();
                            var color = $(this).find("td").eq(10).html();

                            var request = {"codigo":codigo, "nombre":nombre, "precio":precio, "cantidad":cantidad, "descuento":descuento, "isv":isv, "subtotal":subtotal};
                            console.log(request);
                            GuardarDetalleVenta(codigo,precio,cantidad, descuento, subtotal, count, pos);
                            GuardarDetalleProducto(codigo,cantidad, talla, color, count, pos);

                        }
                        count+=1;
                        
                

            });
    }

    function total(){
            let count =0;
            var subtotal =0;
            $('#table2 tr').each(function () {

                        if(count>0){
               
                             subtotal += parseFloat($(this).find("td").eq(8).html());
                        

                        }
                        count+=1;
                

            });
            $("#total").val(subtotal);

    }



    function GuardarDetalleVenta(producto_id, precio, cantidad, descuento, subtotal, count, pos){
        let idorden = $("#orden").val();

        $.ajax({
            method: "POST",
            headers: {
                'X-CSRF-TOKEN': csrfToken,
                'Authorization': 'Basic '+ authorization
            },
            url: "../../api/detalleVentaR/add",
            data: {
                "venta_id": idorden,
                "producto_id": producto_id,
                "precio": precio,
                "cantidad": cantidad,
                "descuento": descuento,
                "isv": 0.00,
                "subtotal": subtotal,
                "estado":1
            }
        })
        .done(function( data ) {
            let response = JSON.parse(JSON.stringify(data));
            if(response['Data_Respuesta'].Codigo==200){

                if(count==pos){
                            disparadorMensaje = 1;
                           

                }
            }
            
        
        }).fail(function(data){
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            mostrarMensaje(response['responseJSON']);
      

        });

    }

    function rollback(venta_id) {

        $.ajax({
            method: "GET",
            headers: {
                'X-CSRF-TOKEN': csrfToken,
                'Authorization': 'Basic '+ authorization
            },
            url: "../../api/ventaR/rollback/"+venta_id,
           
        })
        .done(function( data ) {
            let response = JSON.parse(JSON.stringify(data));
            if(response['Data_Respuesta'].Codigo==200){
                mostrarMensaje(response['Data_Respuesta']);       
            } 
        
        }).fail(function(data){
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            mostrarMensaje(response['responseJSON']);

        });

    }

    function GuardarDetalleProducto(producto_id, cantidad, size_id, color_id, count, pos){
        let idorden = $("#orden").val();

        $.ajax({
            method: "POST",
            headers: {
                'X-CSRF-TOKEN': csrfToken,
                'Authorization': 'Basic '+ authorization
            },
            url: "../../api/detalleProductoR/add",
            data: {
                "venta_id": idorden,
                "producto_id": producto_id,
                "size_id": size_id,
                "cantidad": cantidad,
                "color_id": color_id,
                "estado":1
            }
        })
        .done(function( data ) {
            let response = JSON.parse(JSON.stringify(data));
            if(response['Data_Respuesta'].Codigo==200){
                if(count==pos){
                            disparadorMensaje+=1;
                            if(disparadorMensaje==2){
                                response = {"Codigo":200, "Estado":"Exitoso", "Descripcion": "Venta Registrada"};
                                mostrarMensajeRecibo(response);
                            }
                        

                }
            }
            
        
        }).fail(function(data){
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            rollback(idorden);

        });

    }


    function Guardar(){
        let idorden = $("#orden").val();
        let cliente_id = idcliente;
        let idusuario = <?php echo e(auth()->user()->id); ?>;
        let direccion = $("#direccion").val();
        let total = $("#total").val();
        var d = new Date();
        var strDate = d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate()+ " "+d.getHours()+"-"+d.getMinutes()+"-"+d.getSeconds();
      
        $.ajax({
            method: "POST",
            headers: {
                'X-CSRF-TOKEN': csrfToken,
                'Authorization': 'Basic '+ authorization

            },
            url: "../../api/ventaR/add",
            data: {
                "id":idorden,
                "fecha": strDate,
                "cliente_id": cliente_id,
                "usuario_id": idusuario,
                "direccionEnvio": direccion,
                "total": total,
                "estado": 1,


            }
        })
        .done(function( data ) {
            let response = JSON.parse(JSON.stringify(data));
            if(response['Data_Respuesta'].Codigo==200){
                   recorrer();
            }
            
        
        }).fail(function(data){
            let response = JSON.parse(JSON.stringify(data));
            mostrarMensaje(response['responseJSON']);
            rollback(idorden);

        });
    }

    function ConfirmarPagar(){
        Swal.fire({
        title: 'Confirmacion',
        text: "Desea pagar la orden?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí!'
        }).then((result) => {
        if (result.isConfirmed) {
           Guardar();

        }
        })

    }

   
    function ConsultarVerRecibo(){
         
        Swal.fire({
        title: 'Venta Registrada!',
        text: "Desea ver el recibo?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, mostrarlo!'
        }).then((result) => {
        if (result.isConfirmed) {
            location.href = "../ver/recibo/"+$("#orden").val();

        }else{
            location.href = "../dashboard";
        }
        })
    }

    function Cancelar(){
        
    }


    function ObtenerTallas(idcolor, idproducto){
    $.ajax({
        method: "GET",
        url: '../../api/inventoryR/sizesWithStock/'+idproducto+"/"+idcolor,
        headers: {
        'X-CSRF-TOKEN': csrfToken,
        'Authorization':'Basic '+authorization

         }
        })
        .done(function( data ) {
            let response = JSON.parse(JSON.stringify(data));
            switch (response['Data_Respuesta'].Codigo) {
                case '200':
                    var value ="<option value=\"0\">Seleccione...</option>";
                    var nameSize="";
                    response['Sizes'].forEach(element => {
                    nameSize=element.id;
                    value = value + "<option value="+nameSize+">"+element.name_size+"</option>"
                    });
                    $('#size').empty();
                    $('#size').append(value);
                    break;

                case '202':
                    $("#size").find('option').not(':first').remove();
                    mostrarMensaje(response['Data_Respuesta']);
                    break;
            
            }
           
        
        }).fail(function(data){
            let response = JSON.parse(JSON.stringify(data));
            console.log(response);
            mostrarMensaje(response['responseJSON']);

            

        });

 }
    
    
</script>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('panelp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Edwin Rafael\Desktop\APPFHOPE\resources\views/pos.blade.php ENDPATH**/ ?>